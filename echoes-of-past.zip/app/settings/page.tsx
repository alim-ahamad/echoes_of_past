"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { ArrowLeft, Save, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function SettingsPage() {
  const router = useRouter()
  const [accentColor, setAccentColor] = useState<string>("red")
  const [blurIntensity, setBlurIntensity] = useState<number[]>([3])
  const [enableGlitchEffects, setEnableGlitchEffects] = useState<boolean>(true)
  const [enableSmokeEffects, setEnableSmokeEffects] = useState<boolean>(true)
  const [enableSounds, setEnableSounds] = useState<boolean>(false)
  const [exportFormat, setExportFormat] = useState<string>("json")

  const handleSaveSettings = () => {
    // In a real app, this would save to a database or localStorage
    console.log("Settings saved:", {
      accentColor,
      blurIntensity: blurIntensity[0],
      enableGlitchEffects,
      enableSmokeEffects,
      enableSounds,
      exportFormat,
    })

    router.push("/timeline")
  }

  const handleDeleteAllData = () => {
    if (confirm("Are you sure you want to delete all your memories? This action cannot be undone.")) {
      // In a real app, this would clear the database
      console.log("All data deleted")
      router.push("/")
    }
  }

  return (
    <main className="min-h-screen">
      <header className="border-b border-accent p-4 flex items-center">
        <Button variant="ghost" size="sm" className="mr-2" onClick={() => router.push("/timeline")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-2xl font-bold">Settings</h1>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize how your timeline looks and feels</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="accentColor">Accent Color</Label>
              <Select value={accentColor} onValueChange={setAccentColor}>
                <SelectTrigger>
                  <SelectValue placeholder="Select accent color" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="red">Blood Red</SelectItem>
                  <SelectItem value="purple">Deep Purple</SelectItem>
                  <SelectItem value="blue">Midnight Blue</SelectItem>
                  <SelectItem value="green">Emerald Green</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="blurIntensity">Memory Blur Intensity</Label>
              <Slider
                id="blurIntensity"
                defaultValue={[3]}
                max={10}
                step={1}
                value={blurIntensity}
                onValueChange={setBlurIntensity}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Subtle</span>
                <span>Intense</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="glitchEffects">Glitch Effects</Label>
              <Switch id="glitchEffects" checked={enableGlitchEffects} onCheckedChange={setEnableGlitchEffects} />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="smokeEffects">Smoke Effects</Label>
              <Switch id="smokeEffects" checked={enableSmokeEffects} onCheckedChange={setEnableSmokeEffects} />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="sounds">Enable Sounds</Label>
              <Switch id="sounds" checked={enableSounds} onCheckedChange={setEnableSounds} />
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Export or delete your memories</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="exportFormat">Export Format</Label>
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger>
                  <SelectValue placeholder="Select export format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-between">
              <Button variant="outline">Export All Memories</Button>
              <Button variant="outline">Import Memories</Button>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-start">
            <Separator className="mb-4" />
            <div className="space-y-2 w-full">
              <h3 className="text-sm font-medium text-destructive">Danger Zone</h3>
              <p className="text-xs text-muted-foreground">
                Once you delete your memories, there is no going back. Please be certain.
              </p>
              <Button
                variant="destructive"
                className="w-full flex items-center justify-center gap-2"
                onClick={handleDeleteAllData}
              >
                <Trash2 className="h-4 w-4" />
                Delete All Memories
              </Button>
            </div>
          </CardFooter>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSaveSettings} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </div>
    </main>
  )
}

