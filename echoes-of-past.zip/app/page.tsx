"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import AnimatedQuote from "@/components/animated-quote"
import EnterButton from "@/components/enter-button"

export default function Home() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setLoaded(true)
  }, [])

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 relative overflow-hidden">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: loaded ? 1 : 0 }}
        transition={{ duration: 1.5 }}
        className="absolute inset-0 bg-black"
      />

      <div className="z-10 flex flex-col items-center justify-center gap-8">
        <AnimatedQuote />
        <EnterButton />
      </div>

      <div className="absolute inset-0 bg-gradient-to-t from-destructive/20 to-transparent opacity-30" />
    </main>
  )
}

