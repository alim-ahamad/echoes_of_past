"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Settings } from "lucide-react"
import TimelineEvent, { type TimelineEvent as TimelineEventType } from "@/components/timeline-event"
import TimelineFilters from "@/components/timeline-filters"
import TimeTravelSlider from "@/components/time-travel-slider"
import AddEventForm from "@/components/add-event-form"
import { useRouter } from "next/navigation"

// Sample data - in a real app, this would come from a database
const sampleEvents: TimelineEventType[] = [
  {
    id: "1",
    title: "First Love",
    date: "2015-06-15",
    time: "19:30",
    description:
      "Met Sarah at the coffee shop. We talked for hours about our favorite books and music. I knew there was something special about her from the first moment.",
    regretLevel: 8,
    type: "relationship",
    year: 2015,
    imageUrl: "/placeholder.svg?height=300&width=400",
  },
  {
    id: "2",
    title: "Betrayal by Best Friend",
    date: "2016-11-03",
    description:
      "Found out that Mike had been lying to me for months. He was the one who spread those rumors about me at work. I trusted him with everything.",
    regretLevel: 9,
    type: "betrayal",
    year: 2016,
  },
  {
    id: "3",
    title: "College Graduation",
    date: "2017-05-20",
    time: "10:00",
    description:
      "Finally graduated after years of hard work. My parents were so proud. I felt like I could conquer the world.",
    regretLevel: 2,
    type: "defining",
    year: 2017,
    imageUrl: "/placeholder.svg?height=300&width=400",
  },
  {
    id: "4",
    title: "Lost Connection with Childhood Friend",
    date: "2018-08-12",
    description:
      "Last conversation with Alex before we drifted apart. We promised to stay in touch, but life got in the way. I miss our adventures together.",
    regretLevel: 7,
    type: "friendship",
    year: 2018,
  },
  {
    id: "5",
    title: "Missed Opportunity",
    date: "2019-03-27",
    description:
      "Turned down the job offer in New York. I was too afraid to leave my comfort zone. Sometimes I wonder how different my life would be if I had taken that leap.",
    regretLevel: 8,
    type: "defining",
    year: 2019,
  },
  {
    id: "6",
    title: "The Breakup",
    date: "2020-09-05",
    time: "22:15",
    description:
      "Sarah and I ended things after 5 years. We both knew it was coming, but it still hurt more than I expected. The apartment felt so empty afterward.",
    regretLevel: 9,
    type: "relationship",
    year: 2020,
    audioUrl: "/sample-audio.mp3",
  },
  {
    id: "7",
    title: "Reconnected with Dad",
    date: "2021-12-25",
    description:
      "After years of tension, we finally had a real conversation. We both apologized for the past. It felt like a weight had been lifted.",
    regretLevel: 3,
    type: "defining",
    year: 2021,
  },
  {
    id: "8",
    title: "New Beginning",
    date: "2022-02-14",
    description:
      "Moved to a new city to start fresh. I was terrified but excited. This was my chance to redefine myself.",
    regretLevel: 4,
    type: "defining",
    year: 2022,
    imageUrl: "/placeholder.svg?height=300&width=400",
  },
]

export default function TimelinePage() {
  const [events, setEvents] = useState<TimelineEventType[]>(sampleEvents)
  const [filteredEvents, setFilteredEvents] = useState<TimelineEventType[]>(sampleEvents)
  const [isAddEventOpen, setIsAddEventOpen] = useState(false)
  const [timeTravelYear, setTimeTravelYear] = useState<number | null>(null)
  const router = useRouter()

  const years = [...new Set(events.map((event) => event.year))].sort()

  const handleFilterChange = (filters: {
    type: string[]
    year: number | null
    regretLevel: number[]
  }) => {
    let filtered = [...events]

    // Filter by type
    if (filters.type.length > 0) {
      filtered = filtered.filter((event) => filters.type.includes(event.type))
    }

    // Filter by year
    if (filters.year) {
      filtered = filtered.filter((event) => event.year === filters.year)
    }

    // Filter by regret level
    filtered = filtered.filter(
      (event) => event.regretLevel >= filters.regretLevel[0] && event.regretLevel <= filters.regretLevel[1],
    )

    setFilteredEvents(filtered)
  }

  const handleAddEvent = (newEvent: Omit<TimelineEventType, "id">) => {
    const event = {
      ...newEvent,
      id: `${events.length + 1}`,
    }

    setEvents([...events, event])
    setFilteredEvents([...events, event])
  }

  const handleTimeTravelChange = (year: number) => {
    setTimeTravelYear(year)
  }

  return (
    <main className="min-h-screen pb-24">
      <header className="border-b border-accent p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Echoes of the Past</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
            onClick={() => setIsAddEventOpen(true)}
          >
            <Plus className="h-4 w-4" />
            Add Memory
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
            onClick={() => router.push("/settings")}
          >
            <Settings className="h-4 w-4" />
            Settings
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <TimelineFilters onFilterChange={handleFilterChange} years={years} />

        <div className="relative">
          <div className="absolute left-0 right-0 h-1 bg-accent top-1/2 transform -translate-y-1/2 z-0" />

          <div className="timeline-container overflow-x-auto pb-4">
            <div className="flex min-w-max relative z-10">
              {filteredEvents.length > 0 ? (
                filteredEvents
                  .sort((a, b) => a.year - b.year || new Date(a.date).getTime() - new Date(b.date).getTime())
                  .map((event, index) => <TimelineEvent key={event.id} event={event} index={index} />)
              ) : (
                <div className="flex items-center justify-center w-full py-20">
                  <p className="text-muted-foreground">
                    No memories found. Try adjusting your filters or add a new memory.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <AddEventForm isOpen={isAddEventOpen} onClose={() => setIsAddEventOpen(false)} onAddEvent={handleAddEvent} />

      <TimeTravelSlider years={years} onYearChange={handleTimeTravelChange} />
    </main>
  )
}

