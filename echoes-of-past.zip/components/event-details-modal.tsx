"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Edit, Trash2, Volume2 } from "lucide-react"
import type { TimelineEvent } from "./timeline-event"
import { cn } from "@/lib/utils"

interface EventDetailsModalProps {
  event: TimelineEvent
  isOpen: boolean
  onClose: () => void
}

export default function EventDetailsModal({ event, isOpen, onClose }: EventDetailsModalProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  const handleEdit = () => {
    // Implement edit functionality
    console.log("Edit event:", event.id)
    onClose()
  }

  const handleDelete = () => {
    // Implement delete functionality
    console.log("Delete event:", event.id)
    onClose()
  }

  const toggleAudio = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] bg-card border-accent">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{event.title}</DialogTitle>
          <div className="flex items-center text-sm text-muted-foreground mt-1">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{event.date}</span>
            {event.time && (
              <>
                <Clock className="h-4 w-4 ml-3 mr-1" />
                <span>{event.time}</span>
              </>
            )}
          </div>
        </DialogHeader>

        {event.imageUrl && (
          <div className="w-full h-64 overflow-hidden rounded-md">
            <img src={event.imageUrl || "/placeholder.svg"} alt={event.title} className="w-full h-full object-cover" />
          </div>
        )}

        <div className="space-y-4">
          <p className="text-foreground">{event.description}</p>

          <div>
            <div className="text-sm font-medium mb-1">Regret Level</div>
            <div className="w-full h-3 bg-background rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full",
                  event.regretLevel <= 3
                    ? "regret-meter-low"
                    : event.regretLevel <= 7
                      ? "regret-meter-medium"
                      : "regret-meter-high",
                )}
                style={{ width: `${event.regretLevel * 10}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Low</span>
              <span>Medium</span>
              <span>High</span>
            </div>
          </div>

          {event.audioUrl && (
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="flex items-center gap-2" onClick={toggleAudio}>
                <Volume2 className="h-4 w-4" />
                {isPlaying ? "Pause Audio" : "Play Audio"}
              </Button>
              <div className="text-xs text-muted-foreground">{isPlaying ? "Playing..." : "Voice note available"}</div>
            </div>
          )}
        </div>

        <DialogFooter className="flex justify-between sm:justify-between">
          <Button variant="destructive" size="sm" className="flex items-center gap-2" onClick={handleDelete}>
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
            <Button variant="default" size="sm" className="flex items-center gap-2" onClick={handleEdit}>
              <Edit className="h-4 w-4" />
              Edit
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

