"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Heart, Users, AlertTriangle, Calendar, Filter } from "lucide-react"
import { cn } from "@/lib/utils"

interface TimelineFiltersProps {
  onFilterChange: (filters: {
    type: string[]
    year: number | null
    regretLevel: number[]
  }) => void
  years: number[]
}

export default function TimelineFilters({ onFilterChange, years }: TimelineFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedTypes, setSelectedTypes] = useState<string[]>([])
  const [selectedYear, setSelectedYear] = useState<number | null>(null)
  const [regretLevel, setRegretLevel] = useState<number[]>([0, 10])

  const toggleFilter = (type: string) => {
    if (selectedTypes.includes(type)) {
      setSelectedTypes(selectedTypes.filter((t) => t !== type))
    } else {
      setSelectedTypes([...selectedTypes, type])
    }
  }

  const applyFilters = () => {
    onFilterChange({
      type: selectedTypes,
      year: selectedYear,
      regretLevel: regretLevel,
    })
  }

  const resetFilters = () => {
    setSelectedTypes([])
    setSelectedYear(null)
    setRegretLevel([0, 10])
    onFilterChange({
      type: [],
      year: null,
      regretLevel: [0, 10],
    })
  }

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <Button variant="outline" size="sm" onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>

        {isOpen && (
          <Button variant="ghost" size="sm" onClick={resetFilters}>
            Reset
          </Button>
        )}
      </div>

      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-card border border-border rounded-lg p-4 mb-4"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Event Type</h3>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "flex items-center gap-1",
                    selectedTypes.includes("relationship") && "bg-red-900/30 text-red-400 border-red-900/50",
                  )}
                  onClick={() => toggleFilter("relationship")}
                >
                  <Heart className="h-4 w-4" />
                  Relationships
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "flex items-center gap-1",
                    selectedTypes.includes("friendship") && "bg-blue-900/30 text-blue-400 border-blue-900/50",
                  )}
                  onClick={() => toggleFilter("friendship")}
                >
                  <Users className="h-4 w-4" />
                  Friendships
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "flex items-center gap-1",
                    selectedTypes.includes("betrayal") && "bg-yellow-900/30 text-yellow-400 border-yellow-900/50",
                  )}
                  onClick={() => toggleFilter("betrayal")}
                >
                  <AlertTriangle className="h-4 w-4" />
                  Betrayals
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "flex items-center gap-1",
                    selectedTypes.includes("defining") && "bg-green-900/30 text-green-400 border-green-900/50",
                  )}
                  onClick={() => toggleFilter("defining")}
                >
                  <Calendar className="h-4 w-4" />
                  Defining Moments
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Year</h3>
              <Select
                value={selectedYear?.toString() || ""}
                onValueChange={(value) => setSelectedYear(value ? Number.parseInt(value) : null)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Years" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Regret Level</h3>
              <div className="px-2">
                <Slider
                  defaultValue={[0, 10]}
                  max={10}
                  step={1}
                  value={regretLevel}
                  onValueChange={setRegretLevel}
                  className="my-4"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Low ({regretLevel[0]})</span>
                  <span>High ({regretLevel[1]})</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex justify-end">
            <Button onClick={applyFilters}>Apply Filters</Button>
          </div>
        </motion.div>
      )}
    </div>
  )
}

