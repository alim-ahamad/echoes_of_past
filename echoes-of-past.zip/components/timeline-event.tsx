"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Heart, Users } from "lucide-react"
import { cn } from "@/lib/utils"
import EventDetailsModal from "./event-details-modal"

export interface TimelineEvent {
  id: string
  title: string
  date: string
  time?: string
  description: string
  regretLevel: number
  type: "relationship" | "friendship" | "betrayal" | "defining"
  year: number
  imageUrl?: string
  audioUrl?: string
}

interface TimelineEventProps {
  event: TimelineEvent
  index: number
}

export default function TimelineEvent({ event, index }: TimelineEventProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)

  const getTypeIcon = () => {
    switch (event.type) {
      case "relationship":
        return <Heart className="h-4 w-4 text-red-400" />
      case "friendship":
        return <Users className="h-4 w-4 text-blue-400" />
      case "betrayal":
        return <Users className="h-4 w-4 text-yellow-400" />
      case "defining":
        return <Calendar className="h-4 w-4 text-green-400" />
      default:
        return <Calendar className="h-4 w-4" />
    }
  }

  const getTypeColor = () => {
    switch (event.type) {
      case "relationship":
        return "bg-red-900/30 text-red-400 border-red-900/50"
      case "friendship":
        return "bg-blue-900/30 text-blue-400 border-blue-900/50"
      case "betrayal":
        return "bg-yellow-900/30 text-yellow-400 border-yellow-900/50"
      case "defining":
        return "bg-green-900/30 text-green-400 border-green-900/50"
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-900/50"
    }
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1, duration: 0.5 }}
        whileHover={{ scale: 1.03 }}
        className="min-w-[300px] max-w-[300px] mx-4"
      >
        <Card
          className={cn("memory-card border-2 cursor-pointer overflow-hidden", getTypeColor())}
          onClick={() => setIsModalOpen(true)}
        >
          {event.imageUrl && (
            <div className="h-32 w-full overflow-hidden">
              <img
                src={event.imageUrl || "/placeholder.svg"}
                alt={event.title}
                className="w-full h-full object-cover opacity-60 hover:opacity-80 transition-opacity"
              />
            </div>
          )}
          <CardContent className="p-4">
            <div className="flex justify-between items-start mb-2">
              <Badge variant="outline" className="flex items-center gap-1">
                {getTypeIcon()}
                <span className="capitalize">{event.type}</span>
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                {event.year}
              </Badge>
            </div>
            <h3 className="text-lg font-bold mb-2 line-clamp-2">{event.title}</h3>
            <div className="flex items-center text-xs text-muted-foreground mb-2">
              <Calendar className="h-3 w-3 mr-1" />
              <span>{event.date}</span>
              {event.time && (
                <>
                  <Clock className="h-3 w-3 ml-2 mr-1" />
                  <span>{event.time}</span>
                </>
              )}
            </div>
            <p className="text-sm text-muted-foreground line-clamp-3">{event.description}</p>

            <div className="mt-3">
              <div className="text-xs text-muted-foreground mb-1">Regret Level</div>
              <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full",
                    event.regretLevel <= 3
                      ? "regret-meter-low"
                      : event.regretLevel <= 7
                        ? "regret-meter-medium"
                        : "regret-meter-high",
                  )}
                  style={{ width: `${event.regretLevel * 10}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <EventDetailsModal event={event} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  )
}

