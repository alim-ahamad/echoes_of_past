"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export default function AnimatedQuote() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const quote = "The past never fades, it only waits."

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: isVisible ? 1 : 0 }}
      transition={{ duration: 2 }}
      className="text-center smoke-effect"
    >
      <h1 className="text-4xl md:text-6xl font-bold mb-8 glitch-text" data-text={quote}>
        {quote}
      </h1>
    </motion.div>
  )
}

