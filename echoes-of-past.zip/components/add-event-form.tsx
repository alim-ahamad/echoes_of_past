"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Calendar, Clock, Upload } from "lucide-react"
import type { TimelineEvent } from "./timeline-event"

interface AddEventFormProps {
  isOpen: boolean
  onClose: () => void
  onAddEvent: (event: Omit<TimelineEvent, "id">) => void
}

export default function AddEventForm({ isOpen, onClose, onAddEvent }: AddEventFormProps) {
  const [title, setTitle] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [description, setDescription] = useState("")
  const [regretLevel, setRegretLevel] = useState<number[]>([5])
  const [type, setType] = useState<"relationship" | "friendship" | "betrayal" | "defining">("defining")
  const [year, setYear] = useState<number>(new Date().getFullYear())
  const [imageUrl, setImageUrl] = useState<string>("")
  const [audioUrl, setAudioUrl] = useState<string>("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newEvent = {
      title,
      date,
      time: time || undefined,
      description,
      regretLevel: regretLevel[0],
      type,
      year,
      imageUrl: imageUrl || undefined,
      audioUrl: audioUrl || undefined,
    }

    onAddEvent(newEvent)
    resetForm()
    onClose()
  }

  const resetForm = () => {
    setTitle("")
    setDate("")
    setTime("")
    setDescription("")
    setRegretLevel([5])
    setType("defining")
    setYear(new Date().getFullYear())
    setImageUrl("")
    setAudioUrl("")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] bg-card border-accent">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Add New Memory</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter a title for this memory"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Time (Optional)</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} className="pl-10" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type">Memory Type</Label>
              <Select
                value={type}
                onValueChange={(value: "relationship" | "friendship" | "betrayal" | "defining") => setType(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relationship">Relationship</SelectItem>
                  <SelectItem value="friendship">Friendship</SelectItem>
                  <SelectItem value="betrayal">Betrayal</SelectItem>
                  <SelectItem value="defining">Defining Moment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="year">Year</Label>
              <Input
                id="year"
                type="number"
                value={year}
                onChange={(e) => setYear(Number.parseInt(e.target.value))}
                min="1900"
                max={new Date().getFullYear()}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what happened..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Regret Level (1-10)</Label>
            <Slider defaultValue={[5]} max={10} step={1} value={regretLevel} onValueChange={setRegretLevel} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Low (1)</span>
              <span>Medium (5)</span>
              <span>High (10)</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl">Image URL (Optional)</Label>
            <div className="relative">
              <Upload className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="imageUrl"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="pl-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="audioUrl">Audio URL (Optional)</Label>
            <div className="relative">
              <Upload className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="audioUrl"
                value={audioUrl}
                onChange={(e) => setAudioUrl(e.target.value)}
                placeholder="https://example.com/audio.mp3"
                className="pl-10"
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Save Memory</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

