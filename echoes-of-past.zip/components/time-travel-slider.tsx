"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Slider } from "@/components/ui/slider"
import { cn } from "@/lib/utils"

interface TimeTravelSliderProps {
  years: number[]
  onYearChange: (year: number) => void
}

export default function TimeTravelSlider({ years, onYearChange }: TimeTravelSliderProps) {
  const [selectedYear, setSelectedYear] = useState<number>(years[years.length - 1] || new Date().getFullYear())
  const [blurAmount, setBlurAmount] = useState<number>(0)
  const [sepiaAmount, setSepiaAmount] = useState<number>(0)

  const minYear = Math.min(...years)
  const maxYear = Math.max(...years)
  const currentYear = new Date().getFullYear()

  useEffect(() => {
    // Calculate effects based on how far back in time
    const yearDiff = currentYear - selectedYear
    const maxDiff = currentYear - minYear

    // More blur and sepia for older years
    const blurFactor = Math.min((yearDiff / maxDiff) * 5, 5)
    const sepiaFactor = Math.min((yearDiff / maxDiff) * 0.8, 0.8)

    setBlurAmount(blurFactor)
    setSepiaAmount(sepiaFactor)
  }, [selectedYear, minYear, currentYear, years])

  const handleYearChange = (values: number[]) => {
    const year = values[0]
    setSelectedYear(year)
    onYearChange(year)
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-sm border-t border-accent p-4 z-50">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-sm font-medium">Time Travel Mode</h3>
          <div className="text-xl font-bold">{selectedYear}</div>
        </div>

        <Slider
          defaultValue={[maxYear]}
          min={minYear}
          max={maxYear}
          step={1}
          value={[selectedYear]}
          onValueChange={handleYearChange}
          className="time-travel-slider"
        />

        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>{minYear}</span>
          <span>{maxYear}</span>
        </div>

        <motion.div
          className={cn(
            "fixed inset-0 pointer-events-none z-40",
            selectedYear === currentYear ? "opacity-0" : "opacity-100",
          )}
          style={{
            filter: `blur(${blurAmount}px) sepia(${sepiaAmount})`,
            transition: "filter 0.5s ease-out",
          }}
        />
      </div>
    </div>
  )
}

