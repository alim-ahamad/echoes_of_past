"use client"

import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"

export default function EnterButton() {
  const router = useRouter()

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2, duration: 0.8 }}>
      <Button
        onClick={() => router.push("/timeline")}
        className="bg-destructive hover:bg-destructive/80 text-white px-8 py-6 text-lg"
      >
        Enter the Timeline
      </Button>
    </motion.div>
  )
}

